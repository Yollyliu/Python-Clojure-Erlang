Operating System : iOS

Command line used for test:  clj —> (load-file “sales.clj”)

